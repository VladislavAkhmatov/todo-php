<?php
namespace App;
class Config
{
    const DB_HOST = 'localhost';
    const DB_NAME = 'todo';
    const DB_USER = 'root';
    const DB_PASS = '';
}
?>